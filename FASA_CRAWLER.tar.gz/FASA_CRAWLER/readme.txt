Install dependencies (dotnet core 2.1)
https://www.microsoft.com/net/
2. Modificare program.js per impostare:
a. destinationFolder = cartella dove salvare i file
b. set = cosa scaricare
3. Compilare il progetto: “dotnet build FASA_CRAWLER.csproj”
4. Eseguire il progetto: 
cd bin/Debug/netcoreapp2.1
“dotnet FASA_CRAWLER.dll”

dotnet build FASA_CRAWLER.csproj
cd bin/Debug/netcoreapp2.1
dotnet FASA_CRAWLER.dll
