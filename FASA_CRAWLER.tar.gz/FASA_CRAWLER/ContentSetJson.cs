﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FASA_CRAWLER
{
    public class Rootobject
    {
        public string name { get; set; }
        public string setId { get; set; }
        public string pages { get; set; }
        public string currPage { get; set; }
        public string pageType { get; set; }
        public string b100 { get; set; }
        public string b250 { get; set; }
        public string bkw { get; set; }
        public string bsp { get; set; }
        public string bspAudio { get; set; }
        public Summary summary { get; set; }
        public List[] list { get; set; }
    }

    public class Summary
    {
        public string RaiTvMediaAudioItem { get; set; }
    }

    public class List
    {
        public bool WORKINPROGRESS { get; set; }
        public string type { get; set; }
        public string itemId { get; set; }
        public string weblink { get; set; }
        public string mp3 { get; set; }
        public string hasAudio { get; set; }
        public string image { get; set; }
        public string image_medium { get; set; }
        public string image_300 { get; set; }
        public string image_433 { get; set; }
        public string icona_programma_link { get; set; }
        public string date { get; set; }
        public string name { get; set; }
        public string author { get; set; }
        public string from { get; set; }
        public string tagcloud { get; set; }
        public string desc { get; set; }
        public string bspAudio { get; set; }
        public Ispartof isPartOf { get; set; }
        public string bsp { get; set; }
        public string b100 { get; set; }
        public string b250 { get; set; }
    }

    public class Ispartof
    {
        public string name { get; set; }
    }

}
