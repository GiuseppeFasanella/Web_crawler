﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Net.Http;

namespace FASA_CRAWLER
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //string set = "ContentSet-ba2adb81-4f5d-4b1d-bd9c-260795ab83a0"; // METAMORFOSI
		string set = "ContentSet-143109a7-8a3b-4c5c-8ab6-eb91b232683a"; // 20k leghe
		//string_set = "https://www.raiplayradio.it/playlist/ContentSet-143109a7-8a3b-4c5c-8ab6-eb91b232683a.html";
                //string destinationFolder = @"C:\Users\giuseppe.fasanella\Desktop\FASA_CRAWLER\";
                string destinationFolder = @"/home/gfasanel/Scrivania/FASA_CRAWLER/";

                var urlFormat = "http://www.rai.tv/dl/portaleRadio/programmi/json/liste/{0}-json-A-{1}.html";

                int mp3Idx = 0;
                int pageIdx = 0;
                Rootobject ro = null;

                do
                {
                    var url = string.Format(urlFormat, set, pageIdx++);

                    using (var client = new HttpClient())
                    {
                        var json = client.GetAsync(url).Result.Content.ReadAsStringAsync().Result;

                        ro = JsonConvert.DeserializeObject<Rootobject>(json);

                        foreach (var episodes in ro.list)
                        {
                            Console.WriteLine($"Donloading episode {mp3Idx}");

                            using (var mp3Stream = client.GetAsync(episodes.mp3).Result.Content.ReadAsStreamAsync().Result)
                            {
                                using (Stream destinationFile = File.Create(Path.Combine(destinationFolder, $"{mp3Idx++}.mp3")))
                                {
                                    mp3Stream.CopyTo(destinationFile);
                                }
                            }
                        }
                    }
                } while (pageIdx < int.Parse(ro.pages));

                Console.WriteLine("Completed");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Press any key to quit");
            Console.ReadKey();
        }
    }
}
